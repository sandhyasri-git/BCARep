

package p1;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author Sandhya.Angara
 */
public class User {
    private String username,password,address;
    Connection con=null;
    PreparedStatement ps=null;
    ResultSet rs=null;
    String dbuser,dbpass;

    public User(String username, String password, String address) {
        this.username = username;
        this.password = password;
        this.address = address;
    }

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }
   private Connection createConnection() throws ClassNotFoundException, SQLException
    {
        Class.forName("com.mysql.jdbc.Driver");
        con=DriverManager.getConnection("jdbc:mysql://localhost:3306/world","root","root");
        return con;
    }
    public int storeRecords() throws ClassNotFoundException, SQLException
    {
        int x=-1;
        createConnection();
        ps=con.prepareStatement("insert into user values(?,?,?)");
        ps.setString(1,this.username);
        ps.setString(2, this.password);
        ps.setString(3, this.address);
      //  x=ps.executeUpdate();
        return x;
    }
    public int loginCheck() throws ClassNotFoundException, SQLException
    {
        int x=-1;
        createConnection();
        ps=con.prepareStatement("select username,password from user where username=?");
        ps.setString(1,this.username);
        rs=ps.executeQuery();
        while(rs.next()){
            dbuser=rs.getString(1);
            dbpass=rs.getString(2);
        }
        if(this.username.equals(dbuser)&& this.password.equals(dbpass)){
            x=1;
        }
        return x;
    }
}
